document.getElementById('prijava').addEventListener('click', function(){
    window.location.href='nalog.html';
});


function odjaviSe() {
    window.location.href = "index.html";
}

document.addEventListener('DOMContentLoaded', function () {
    const kupiButtons = document.querySelectorAll('.kupi-btn');

    kupiButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            alert('Molimo vas da se prijavite pre nego što kupite proizvod.');
        });
    });
});


